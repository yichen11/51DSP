$(function(){
	$("#indexLeft").css("height", function() {
		var hg = $(".swiper-wrapper").height();
		return hg + "px";
	})
	$("#footerNav").css("top", function() {
		var hg = $(".swiper-wrapper").height();
		return (hg - 67) + "px";
	})
	$(".swiper-container").css("width", function() {
		var wid = $("body").width() - $("#indexLeft").width();
		return wid + "px";
	})
	

	$(".indexLeftBr").click(function(){
			if($(".nav_slide").is(":hidden")){
				$(".nav_slide").slideDown(1000);
			}else{
				$(".nav_slide").slideUp(1000);
			}
		})
		if($("body").width()<1200){
				$("#navSelect").hide();
				$(".nav_slide").slideDown(1000);
			}else{
				$("#navSelect").show();
				$(".nav_slide").slideUp(1000);
			}
	$(window).resize(function(){
		if($("body").width() <= 1200){
		
			$("#navSelect").hide();
			if($(".nav_slide").is(":hidden")){
				$(".nav_slide").slideDown(1000);
			}
		}else{
			
			$("#navSelect").show();
			if(!$(".nav_slide").is(":hidden")){
				$(".nav_slide").slideUp(1000);
			}
		}
		$("#indexLeft").css("height", function() {
			var hg = $(".swiper-wrapper").height();
			return hg + "px";
		})
		$(".swiper-container").css("width", function() {
			var wid = $("body").width() - $("#indexLeft").width();
			return wid + "px";
		})
	})
	
	var time = null;

function today() {
	var myDate = new Date();
	var Years = myDate.getFullYear();
	var Months = myDate.getMonth() + 1;
	var Dates = myDate.getDate();
	var Times = Years + "年" + Months + "月" + Dates + "日";
	$(".calendar span").empty().append(Times);
}
time = setInterval(today, 1000)

var navSelect = document.getElementById('navSelect');
var selectLi = navSelect.getElementsByTagName('li');
var navCurrent = document.getElementById("navCurrent");
var navs = 0;
var curnavs = 0;
var navTime = null;
for (var i = 0; i < selectLi.length; i++) {
	selectLi[i].onmouseover = (function(num) {
		return function() {
			navs = num;

		}
	})(i);
	selectLi[i].onmouseout = (function(num) {
		return function() {
			navs = 0;
		}
	})(i);
}

navTime = setInterval(navMove, 10)

function navMove() {
	if (navCurrent.offsetLeft < 120 * navs) {
		navCurrent.style.left = navCurrent.offsetLeft + 10 + "px";
		curnavs = navs;
	} else if (navs < curnavs) {
		navCurrent.style.left = navCurrent.offsetLeft - 10 + "px";
	} else if (navs == 0) {
		if (navCurrent.offsetLeft > 0) {
			navCurrent.style.left = navCurrent.offsetLeft - 10 + "px";


		}
	}
}



})
