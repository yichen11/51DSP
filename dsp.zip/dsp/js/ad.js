
var mySwiper = new Swiper('.swiper-container', {
	speed: 1000,
	effect : 'fade',
	direction: 'vertical',
	pagination: '.swiper-pagination',
	paginationClickable: true,


	keyboardControl: true,
	mousewheelControl: true,

	onSlideChangeStart: function(swiper) { //滑动start判断当前页面  

		//滑动start判断当前页面  end
		// 第一页
		if (mySwiper.activeIndex == "0") {
			var hg = $(".swiper-wrapper").height();
			$("#footerNav").animate({
				top: (hg - 66) + "px"
			}, 1000);
		}


		// 第二页
		if (mySwiper.activeIndex == "1") {
			$("#footerNav").animate({
				top:"0px"
			}, 1000);
		 
			$(".T2thdisplay").animate({
				opacity: 1
			}, 2000)
		}

		//第三页
		if (mySwiper.activeIndex == "2") {
			var ps1 = $(".T3one span").eq(0);
			var ps2 = $(".T3one span").eq(1);
			var ps3 = $(".T3three span").eq(0);
			var ps1img = $(".T3one div").eq(0);
			var ps2img = $(".T3one div").eq(1);
			var ps3img1 = $(".T3three div").eq(0);
			var ps3img2 = $(".T3three div").eq(1);
			$(".arrow").animate({ //箭头
				height: "420px"
			}, 3000)
			$(function() { //三个标签添加样式
				setTimeout(function() {
					$(ps1).addClass("ps1")
				}, 700)
			})
			$(function() {
				setTimeout(function() {
					$(ps2).addClass("ps2")
				}, 2100)
			})
			$(function() {
				setTimeout(function() {
					$(ps3).addClass("ps3")
				}, 1400)
			})

			$(function() { //几个块
				setTimeout(function() {
					$(ps1img).addClass("ps1-img")
				}, 1100)
			})
			$(function() {
				setTimeout(function() {
					$(ps2img).addClass("ps2-img")
				}, 2500)
			})
			$(function() {
				setTimeout(function() {
					$(ps3img1).addClass("ps3-img1")
				}, 1800)
			})
			$(function() {
				setTimeout(function() {
					$(ps3img2).addClass("ps3-img2")
				}, 1900)
			})
		}


		//第四页
		if (mySwiper.activeIndex == "3") {
			
			var active = $(".inner");
			active.each(function(index, obj) {
				
				$(obj).hover(function() {
					$(this).stop(true,true).animate({
						marginTop: "-60px"
					}, 500)
				}, function() {
					$(this).stop(true,true).animate({
						marginTop: "0px"
					}, 500)
				})
			})
		}

		//第五页


	},
	onSlideChangeEnd: function(swiper) {
		//第一页
		

		//第二页
		if (mySwiper.activeIndex != "1") {
			$(".T2thdisplay").css({
				"opacity": "0"
			})
		}



	}
})


	$('.input2 label').click(function() {
		$(".input2 label").each(function() {
			$(this).removeAttr('class');

		})
		$(".input2 input").each(function() {
			$(this).removeAttr("checked");
		})

		$(this).attr('class', 'checked');
		$(this).prev().attr("checked", "checked");
	});


	$('.yuji label').click(function() {
		$(".yuji label").each(function() {
			$(this).removeAttr('class');

		})
		$(".yuji input").each(function() {
			$(this).removeAttr("checked");
		})

		$(this).attr('class', 'checked');
		$(this).prev().attr("checked", "checked");
	});

$(".inp2").attr("disabled", "false");

$("#lab3").click(function() {
	$(".inp2").removeAttr("disabled");
})


$(".inp2").blur(function() {
	$(".inp2").attr("disabled", "false");
})
var re0 = /^[\u4e00-\u9fa5]{2,4}$/;
var re1 = /^[1][34578][0-9]{9}$/i;
var re2 = /^[a-zA-Z0-9_]{2,10}@[a-z0-9]{2,5}\.[a-z]{2,5}$/i;
var ree = [re0, re1, re2];
$("#toper").animate({
	top: 0
}, 500);

function pd() {
	var aa = trim($('.inp').eq(0).val());
	var bb = trim($('.inp').eq(1).val());
	var cc = trim($('.inp').eq(2).val());
	if (aa != "" && bb != "" && cc != "") {
		$('.sub2').eq(0).addClass("inpinput");
	} else {
		$('.sub2').eq(0).removeClass("inpinput");
	}
}
setInterval(pd, 10);

function trim(str) {
	var a = str.replace(/(^\s*)|(\s*$)/g, "");
	return a;
}

function getLength(str) {
	str = getValue1(str);
	return String(str).replace(/[^\x00-\xff]/g, 'cc').length;
}

function getValue1(str) {
	return String(str).replace(/(^\s*)|(\s*$)|(\s*)/g, '');
}

$('.txt textarea').focusout(function() {
	$('i').html("");
})

function yz(index) {
	if (ree[index].test($('.inp').val())) {
		$('.inp').eq(index).css('border', '1px white solid');
	} else {
		$('.inp').eq(index).css('border', '1px red solid');
	}
}